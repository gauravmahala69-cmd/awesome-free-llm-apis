<h1 align="center">
	<a href="https://github.com/mnfst/awesome-free-llm-apis">
		<img src="media/awesome-free-llm-apis.png" width="500" alt="Awesome Free LLM APIs">
	</a>
</h1>

<p align="center">
	<a href="https://awesome.re">
		<img src="https://awesome.re/badge-flat2.svg" alt="Awesome">
	</a>
</p>

<p align="center">LLM APIs with permanent free tiers for text inference.</p>

<p align="center"><sub>Most providers offer an OpenAI-compatible endpoint. Native and compatible base URLs can differ. Each link points to the provider's API key page.</sub></p>

<p align="center"><sub>All of those free LLM APIs are available at <a href="https://manifest.build">manifest.build</a> - make reliable agents.</sub></p>

<hr>

<h3 align="center">Gold sponsors</h3>

<p align="center">
	<a href="https://opencollective.com/awesome-free-llm-apis">
		<picture>
			<source media="(prefers-color-scheme: dark)" srcset="media/sponsor-slot-dark.svg">
			<img src="media/sponsor-slot-light.svg" width="280" alt="Your logo here">
		</picture>
	</a>
</p>

<h3 align="center">Sponsors</h3>

<p align="center">
	<a href="https://okapi.bot/go/awesome-free-llm-apis">
		<picture>
			<source media="(prefers-color-scheme: dark)" srcset="media/okapi-logo-dark.svg">
			<img src="media/okapi-logo-light.svg" width="140" alt="Okapi">
		</picture>
	</a>
	<br>
	<sub>Free API watcher. No more breaking changes.</sub>
</p>

<p align="center"><sub>250,000+ views a month from developers · <a href="https://opencollective.com/awesome-free-llm-apis">Become a sponsor</a></sub></p>

<hr>

## Contents

- [Provider APIs](#provider-apis)
- [Inference providers](#inference-providers)
- [Glossary](#glossary)

## Provider APIs

APIs run by the companies that train or fine-tune the models themselves.

### [Aion Labs](https://www.aionlabs.ai/app/api-keys/) 🇮🇱

Permanent free tier, no credit card required. 15 RPM, 20K tokens/day. Specialized for roleplay and storytelling.

Base URL: `https://api.aionlabs.ai/v1`

| Model Name                       | Context | Max Output | Modality         | Rate Limit      |
| -------------------------------- | ------- | ---------- | ---------------- | --------------- |
| `aion-labs/aion-2.0`             | 128K    | 32K        | Text (reasoning) | 15 RPM, 20K TPD |
| `aion-labs/aion-rp-llama-3.1-8b` | 32K     | 32K        | Text             | 15 RPM, 20K TPD |
| `aion-labs/aion-3.0`             | 128K    | 32K        | Text (reasoning) | 15 RPM, 20K TPD |
| `aion-labs/aion-3.0-mini`        | 128K    | 32K        | Text (reasoning) | 15 RPM, 20K TPD |

### [Cohere](https://dashboard.cohere.com/api-keys) 🇨🇦

Free "Trial" API key, no credit card. 1,000 API calls/month. Non-commercial use only.

Native API base URL: `https://api.cohere.com/v2`

OpenAI-compatible base URL: `https://api.cohere.ai/compatibility/v1`

| Model Name          | Context | Max Output | Modality         | Rate Limit |
| ------------------- | ------- | ---------- | ---------------- | ---------- |
| Command A+ (218B)   | 128K    | 64K        | Text + Image     | 20 RPM     |
| Command A (111B)    | 256K    | 8K         | Text             | 20 RPM     |
| Command R+          | 128K    | 4K         | Text             | 20 RPM     |
| Command R           | 128K    | 4K         | Text             | 20 RPM     |
| Command R7B         | 128K    | 4K         | Text             | 20 RPM     |
| Command A Reasoning | 256K    | 32K        | Text (reasoning) | 20 RPM     |
| Command A Translate | 8K      | 8K         | Text             | 20 RPM     |
| Command A Vision    | 128K    | 8K         | Text + Image     | 20 RPM     |
| Command R7B Arabic  | 128K    | ~4K        | Text             | 20 RPM     |
| Aya Expanse 32B     | 128K    | 4K         | Text             | 20 RPM     |
| Aya Vision 32B      | 16K     | 4K         | Text + Image     | 20 RPM     |

### [Google Gemini](https://aistudio.google.com/app/apikey) 🇺🇸

Free tier, no credit card. Free-tier prompts may be used by Google to improve products. [^1]

Native API base URL: `https://generativelanguage.googleapis.com/v1beta`

OpenAI-compatible base URL: `https://generativelanguage.googleapis.com/v1beta/openai/`

| Model Name            | Context | Max Output | Modality                     | Rate Limit |
| --------------------- | ------- | ---------- | ---------------------------- | ---------- |
| Gemini 3.8 Flash      | 1M      | 65K        | Text + Image + Audio + Video | —          |
| Gemini 3.6 Flash      | 1M      | 65K        | Text + Image + Audio + Video | —          |
| Gemini 3.5 Flash-Lite | 1M      | 65K        | Text + Image + Audio + Video | —          |
| Gemini 3.1 Flash-Lite | 1M      | 65K        | Text + Image + Audio + Video | —          |
| Gemini 2.5 Flash      | 1M      | 65K        | Text + Image + Audio + Video | —          |
| Gemini 2.5 Flash-Lite | 1M      | 65K        | Text + Image + Audio + Video | —          |
| Gemma 4 31B           | 256K    | 32K        | Text + Image                 | —          |
| Gemma 4 26B A4B       | 256K    | 32K        | Text + Image                 | —          |

### [Z AI (Zhipu AI)](https://open.bigmodel.cn/usercenter/apikeys) 🇨🇳

Permanent free models, no credit card required. [^12]

Base URL: `https://open.bigmodel.cn/api/paas/v4`

| Model Name                           | Context | Max Output | Modality         | Rate Limit           |
| ------------------------------------ | ------- | ---------- | ---------------- | -------------------- |
| GLM-4.7-Flash                        | 200K    | 128K       | Text (reasoning) | 1 concurrent request |
| GLM-4.5-Flash (retirement announced) | 128K    | 96K        | Text (reasoning) | 1 concurrent request |
| GLM-4.6V-Flash                       | 128K    | 32K        | Multimodal       | 1 concurrent request |

## Inference providers

Third-party platforms that host open-weight models from various sources.

### [Cloudflare Workers AI](https://dash.cloudflare.com/profile/api-tokens) 🇺🇸

10,000 Neurons/day free, no credit card required. 60+ models available on the free tier. [^11]

Native API base URL: `https://api.cloudflare.com/client/v4/accounts/{account_id}/ai/run`

OpenAI-compatible base URL: `https://api.cloudflare.com/client/v4/accounts/{account_id}/ai/v1`

| Model Name                                     | Context | Max Output        | Modality                       | Rate Limit               |
| ---------------------------------------------- | ------- | ----------------- | ------------------------------ | ------------------------ |
| `@cf/meta/llama-3.3-70b-instruct-fp8-fast`     | 24K     | Shared w/ context | Text                           | 10K neurons/day (shared) |
| `@cf/meta/llama-4-scout-17b-16e-instruct`      | 131K    | Shared w/ context | Multimodal                     | 10K neurons/day (shared) |
| `@cf/openai/gpt-oss-120b`                      | 128K    | Shared w/ context | Text                           | 10K neurons/day (shared) |
| `@cf/google/gemma-4-26b-a4b-it`                | 256K    | Shared w/ context | Text + Vision                  | 10K neurons/day (shared) |
| `@cf/zai-org/glm-4.7-flash`                    | 131K    | Shared w/ context | Text                           | 10K neurons/day (shared) |
| `@cf/mistralai/mistral-small-3.1-24b-instruct` | 128K    | Shared w/ context | Text + Vision                  | 10K neurons/day (shared) |
| `@cf/deepseek-ai/deepseek-r1-distill-qwen-32b` | 80K     | Shared w/ context | Text (reasoning)               | 10K neurons/day (shared) |
| + 55 more models                               | Varies  | Varies            | Text, Image, Audio, Embeddings | 10K neurons/day (shared) |

### [Gonka Broker](https://app.gonkabroker.com/signup) 🇺🇸

Permanent free tier, no credit card required; phone verification required. ~1M tokens/month (shared, varies by model), resets monthly. Model lineup rotates with network governance — live list at /v1/models. [^14]

Base URL: `https://proxy.gonkabroker.com/v1`

| Model Name                           | Context | Max Output | Modality         | Rate Limit                                 |
| ------------------------------------ | ------- | ---------- | ---------------- | ------------------------------------------ |
| `MiniMaxAI/MiniMax-M2.7`             | 200K    | 16K        | Text (reasoning) | ~1M tokens/month (shared, varies by model) |
| `deepseek-ai/DeepSeek-V4-Flash-0731` | 400K    | 16K        | Text (reasoning) | ~1M tokens/month (shared, varies by model) |
| `zai-org/GLM-5.3-Flash`              | 400K    | 16K        | Text (reasoning) | ~1M tokens/month (shared, varies by model) |
| `BAAI/bge-m3`                        | 8K      | —          | Embeddings       | ~1M tokens/month (shared, varies by model) |

### [Groq](https://console.groq.com/keys) 🇺🇸

Free tier, no credit card. Ultra-fast LPU inference. [^2]

Base URL: `https://api.groq.com/openai/v1`

| Model Name            | Context | Max Output | Modality     | Rate Limit                                |
| --------------------- | ------- | ---------- | ------------ | ----------------------------------------- |
| `openai/gpt-oss-120b` | 131K    | 65K        | Text         | 30 RPM, 1,000 RPD, 8,000 TPM, 200,000 TPD |
| `openai/gpt-oss-20b`  | 131K    | 65K        | Text         | 30 RPM, 1,000 RPD, 8,000 TPM, 200,000 TPD |
| `qwen/qwen3.8-27b`    | 131K    | 16K        | Text + Image | 30 RPM, 1,000 RPD, 8,000 TPM, 200,000 TPD |

### [Kilo Code](https://app.kilo.ai/profile) 🇺🇸

Free models with no credit card and no API key required. `kilo-auto/free` auto-router dynamically routes to models in the free pool. [^5]

Base URL: `https://api.kilo.ai/api/gateway`

| Model Name                                           | Context | Max Output | Modality      | Rate Limit |
| ---------------------------------------------------- | ------- | ---------- | ------------- | ---------- |
| `nvidia/nemotron-3-ultra-550b-a55b:free`             | 1M      | 65K        | Text          | 200 req/hr |
| `nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free` | 256K    | 65K        | Multimodal    | 200 req/hr |
| `cohere/north-mini-code:free`                        | 256K    | 64K        | Text (code)   | 200 req/hr |
| `openrouter/free`                                    | Varies  | Varies     | Text          | 200 req/hr |
| `nvidia/nemotron-3.5-lightning:free`                 | 1M      | 65K        | Text          | 200 req/hr |
| `kilo-auto/free`                                     | 256K    | 32K        | Text          | 200 req/hr |
| `dots-studio/dots-3-note-preview:free`               | 512K    | 460K       | Text + Vision | 200 req/hr |
| `nvidia/nemotron-3.5-super-vl:free`                  | 1M      | 131K       | Multimodal    | 200 req/hr |
| `stealth/glyph-cluster`                              | 256K    | 256K       | Text (code)   | 200 req/hr |

### [LLM7.io](https://token.llm7.io) 🇬🇧

API gateway with a free tier. Anonymous access needs no key and reaches the `turbo` models; a free token from token.llm7.io raises the rate and token limits but reaches the same models. [^10]

Base URL: `https://api.llm7.io/v1`

| Model Name                 | Context | Max Output | Modality | Rate Limit                      |
| -------------------------- | ------- | ---------- | -------- | ------------------------------- |
| `gpt-oss:20b`              | 128K    | —          | Text     | 60 RPM, 250 req/hr (free token) |
| mistral-Nemo-Instruct-2407 | 128K    | —          | Text     | 60 RPM, 250 req/hr (free token) |
| codestral-latest           | 32K     | —          | Text     | 60 RPM, 250 req/hr (free token) |

### [ModelScope](https://modelscope.cn/my/myaccesstoken) 🇨🇳

Free API-Inference for registered users. Requires Alibaba Cloud account binding + real-name verification. [^6]

Base URL: `https://api-inference.modelscope.cn/v1`

| Model Name                     | Context | Max Output | Modality  | Rate Limit                                 |
| ------------------------------ | ------- | ---------- | --------- | ------------------------------------------ |
| `Qwen/Qwen3.5-35B-A3B`         | 256K    | —          | Text      | 2,000 RPD total; <=500 RPD/model (dynamic) |
| `Qwen/Qwen3.5-27B`             | 256K    | —          | Text      | 2,000 RPD total; <=500 RPD/model (dynamic) |
| + API-Inference-enabled models | Varies  | Varies     | LLM, MLLM | Dynamic quotas + dynamic concurrency       |

### [NVIDIA NIM](https://build.nvidia.com/explore/discover) 🇺🇸

Free with NVIDIA Developer Program membership. 100+ models. Rate-limited per model. [^15]

Base URL: `https://integrate.api.nvidia.com/v1`

| Model Name                          | Context | Max Output | Modality                               | Rate Limit |
| ----------------------------------- | ------- | ---------- | -------------------------------------- | ---------- |
| `nvidia/nemotron-3-ultra-550b-a55b` | 1M      | 262K       | Text                                   | —          |
| `openai/gpt-oss-20b`                | 131K    | 131K       | Text                                   | —          |
| + 92 more models                    | Varies  | Varies     | Text, Image, Video, Speech, Embeddings | —          |

### [OpenRouter](https://openrouter.ai/keys) 🇺🇸

17 free models (marked with `:free` suffix). OpenAI SDK-compatible. [^4]

Base URL: `https://openrouter.ai/api/v1`

| Model Name                                           | Context | Max Output | Modality                     | Rate Limit     |
| ---------------------------------------------------- | ------- | ---------- | ---------------------------- | -------------- |
| `cohere/north-mini-code:free`                        | 256K    | 64K        | Text (code)                  | 20 RPM, 50 RPD |
| `google/gemma-4-26b-a4b-it:free`                     | 262K    | 32K        | Text + Image + Video         | 20 RPM, 50 RPD |
| `google/gemma-4-31b-it:free`                         | 262K    | 32K        | Text + Image + Video         | 20 RPM, 50 RPD |
| `dots-studio/dots-3-note-preview:free`               | 512K    | 460K       | Text + Image                 | 20 RPM, 50 RPD |
| `liquid/lfm-2.5-2.6b:free`                           | 64K     | 8K         | Text                         | 20 RPM, 50 RPD |
| `nvidia/nemotron-3.5-lightning:free`                 | 1M      | 65K        | Text                         | 20 RPM, 50 RPD |
| `nvidia/nemotron-3-ultra-550b-a55b:free`             | 1M      | 65K        | Text                         | 20 RPM, 50 RPD |
| `recursive/flint-v1.0:free`                          | 262K    | 235K       | Text                         | 20 RPM, 50 RPD |
| `nvidia/nemotron-3.5-super-vl:free`                  | 1M      | 131K       | Text + Image + Video         | 20 RPM, 50 RPD |
| `nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free` | 256K    | 65K        | Text + Image + Audio + Video | 20 RPM, 50 RPD |

### [OVHcloud AI Endpoints](https://www.ovhcloud.com/en/public-cloud/ai-endpoints/catalog/) 🇫🇷

Free anonymous tier (no API key, no signup): 2 RPM per IP per model. 20+ open-weight models hosted in EU. OpenAI SDK-compatible. [^7]

Base URL: `https://oai.endpoints.kepler.ai.cloud.ovh.net/v1`

| Model Name                     | Context | Max Output | Modality      | Rate Limit        |
| ------------------------------ | ------- | ---------- | ------------- | ----------------- |
| Qwen3.5-397B-A17B              | 262K    | ~32K       | Text + Vision | 2 RPM (anonymous) |
| gpt-oss-120b                   | 131K    | ~32K       | Text          | 2 RPM (anonymous) |
| gpt-oss-20b                    | 131K    | ~8K        | Text          | 2 RPM (anonymous) |
| Meta-Llama-3_3-70B-Instruct    | 131K    | ~4K        | Text          | 2 RPM (anonymous) |
| Qwen3.8-27B                    | 262K    | —          | Text + Vision | 2 RPM (anonymous) |
| Qwen3.6-27B                    | 262K    | ~32K       | Text + Vision | 2 RPM (anonymous) |
| Qwen3.5-9B                     | 262K    | ~8K        | Text + Vision | 2 RPM (anonymous) |
| Qwen2.5-VL-72B-Instruct        | 32K     | ~8K        | Text + Vision | 2 RPM (anonymous) |
| Mistral-Small-3.2-24B-Instruct | 128K    | ~4K        | Text + Vision | 2 RPM (anonymous) |

### [SiliconFlow](https://cloud.siliconflow.cn/account/ak) 🇨🇳

Permanently free models, no credit card required. Identity verification required. 100+ models in the catalog, most of them paid. [^9]

Base URL: `https://api.siliconflow.cn/v1`

| Model Name                | Context | Max Output | Modality | Rate Limit |
| ------------------------- | ------- | ---------- | -------- | ---------- |
| `tencent/Hunyuan-MT-7B`   | —       | —          | Text     | —          |
| `XingChenAGI/Xing4.0-29B` | —       | —          | Text     | —          |

## Glossary

| Abbreviation | Meaning             |
| ------------ | ------------------- |
| **RPM**      | Requests per minute |
| **RPD**      | Requests per day    |
| **TPM**      | Tokens per minute   |
| **TPD**      | Tokens per day      |
| **RPS**      | Requests per second |

## Contributing

Know a free tier that's missing? [Open a PR](contributing.md). Include the provider, endpoint, rate limits (link to their docs), and a few notable models. Trial credits and time-limited promos don't count.

[^1]: The Gemini API free tier is available to developers in the EU, UK, and Switzerland; the [available regions](https://ai.google.dev/gemini-api/docs/available-regions) page lists these regions. The [terms](https://ai.google.dev/gemini-api/terms) still require you to use only Paid Services when you make an API Client available to users in the European Economic Area, Switzerland, or the UK. Google no longer publishes per-model free-tier rate limits; check your quotas in [AI Studio](https://aistudio.google.com/). Free-tier prompts may be used by Google to improve products, except for users in the EEA, Switzerland and the UK, where the paid-services data terms also govern the unpaid quota, so those prompts are not used to improve Google products. `gemini-3.1-flash-lite` is on the [deprecation schedule](https://ai.google.dev/gemini-api/docs/deprecations), with a shutdown date of May 7, 2027 and `gemini-3.5-flash-lite` as its replacement; the row stays because the model is live and free today.
[^2]: Groq shut down qwen/qwen3.6-27b on September 14, 2026 (replaced by qwen/qwen3.8-27b) and groq/compound and groq/compound-mini on September 21, 2026 ([deprecations](https://console.groq.com/docs/deprecations)). Free-plan limits vary by model; the chat models listed get 30 RPM, 1,000 RPD, 8,000 TPM, and 200,000 TPD on the official [Free Plan Limits](https://console.groq.com/docs/rate-limits) table. Exact organization limits are on the account limits page.
[^4]: Free models allow 20 requests per minute and 50 requests per day, counted across all free models. Accounts that bought at least 10 credits get 1,000 requests per day ([limits](https://openrouter.ai/docs/api-reference/limits)). OpenRouter also offers a [Free Models Router](https://openrouter.ai/docs/guides/routing/routers/free-router) (`openrouter/free`) and [model fallbacks](https://openrouter.ai/docs/guides/routing/model-fallbacks) for chaining models in priority order. Free providers may log prompts for training.
[^5]: Kilo Code's free pool changes frequently, and the /api/gateway/models catalog can lag what is actually served: probe results have confirmed models absent from the catalog still answering. Rows through liquid/lfm-2.5-2.6b:free answered a live request between 2026-08-19 and 2026-08-21; the rows after it were added on 2026-10-05 (through dots-studio/dots-3-note-preview:free), 2026-10-23 and 2026-10-25 from the catalog, where they are priced at $0, and have not been probed. Free models are reachable with no API key, at 200 requests per hour per IP ([authentication](https://kilo.ai/docs/gateway/authentication)). The kilo-auto/free router picks a model from the free pool, and Kilo's docs warn it "may route your requests to providers that log prompts and outputs". The NVIDIA free endpoints carry NVIDIA's own condition, quoted on Kilo's [models page](https://kilo.ai/docs/gateway/models-and-providers): "Trial use only - do not submit personal or confidential data. Your use is logged for security purposes and to improve NVIDIA products and services."
[^6]: API-Inference is free for registered users. Current published limits are 2,000 requests/day per user (total across models), with per-model daily quotas dynamically adjusted and capped at 500; concurrency is also dynamically rate-limited. Requires Alibaba Cloud account binding and real-name verification ([limits](https://modelscope.cn/docs/model-service/API-Inference/limits), [intro](https://modelscope.cn/docs/model-service/API-Inference/intro)). This entry is based on ModelScope's documentation. It cannot be tested from outside mainland China.
[^7]: OVHcloud AI Endpoints offers a permanent free anonymous tier (2 requests per minute per IP, per model) with no signup or API key required. Higher rate limits (400 RPM per Public Cloud project per model) require an API key and are billed pay-as-you-go per token; new Public Cloud accounts get up to $200 in free trial credits. Models are hosted in EU data centers. The catalog lists an end of life on November 4, 2026 for Mistral-Small-3.2-24B-Instruct-2506 and Mistral-Nemo-Instruct-2407.
[^9]: SiliconFlow requires real-name identity verification to use free models (effective May 15, 2026, per the [release notes](https://api-docs.siliconflow.cn/docs/release-notes/overview)). Verification supports mainland-Chinese documents; international users must contact support. This entry is based on SiliconFlow's [pricing page](https://siliconflow.cn/pricing), which marks these models free. It cannot be tested from outside mainland China.
[^10]: LLM7.io rotates its catalog frequently, so the model list changes between checks. Access is tier-based, not token-based: `turbo` models are reachable anonymously or with a free token, `pro` models need the paid plan ([models API](https://docs.llm7.io/guides/models-api)). A free token is capped at 1 RPS, 60 RPM, 250 requests per hour and 100,000 tokens per 24 hours, and the free quota may be reduced without notice ([limits](https://docs.llm7.io/limits)). A paid Pro plan is available at $12/month. The docs no longer list anonymous (no-key) limits; anonymous access was last confirmed by live request on 2026-08-21.
[^11]: The 10,000 free Neurons are shared across all Workers AI usage, not per model, and all limits reset daily at 00:00 UTC. Going over does not bill you, the request fails. Seven models are excluded from Workers Free billing and need the Workers Paid plan or prepaid AI Gateway credits: `@cf/moonshotai/kimi-k2.6`, `@cf/moonshotai/kimi-k2.7-code`, `@cf/zai-org/glm-5.2`, `@cf/zai-org/glm-5.3`, `@cf/zai-org/glm-5.3-flash`, `@cf/deepseek-ai/deepseek-v4-flash-0731`, `@cf/deepseek-ai/deepseek-v4-pro-0813` ([pricing](https://developers.cloudflare.com/workers-ai/platform/pricing/)).
[^12]: Registration accepts overseas phone numbers ([registration FAQ](https://docs.bigmodel.cn/cn/faq/registration-login.md)) and the chat API does not require real-name verification: 目前调用 API 并不强制要求实名认证 ([authentication FAQ](https://docs.bigmodel.cn/cn/faq/authentication-issues.md)). The Batch API does require it ([batch FAQ](https://docs.bigmodel.cn/cn/faq/batch-api-issues.md)). The same free models are served from the international platform at `https://api.z.ai/api/paas/v4` ([endpoint](https://docs.z.ai/guides/develop/http/introduction)), where GLM-4.7-Flash, GLM-4.5-Flash and GLM-4.6V-Flash are all priced Free ([pricing](https://docs.z.ai/guides/overview/pricing.md)). Z AI has announced that GLM-4.5-Flash will be retired and its requests auto-routed to GLM-4.7-Flash ([model page](https://docs.bigmodel.cn/cn/guide/models/free/glm-4.5-flash.md)); the announced date has already passed while the model is still catalogued and still priced Free, so treat that row as living on borrowed time.
[^14]: The free grant is issued only after SMS verification with a real (non-VoIP) phone number, one grant per number ([billing docs](https://docs.gonkabroker.com/guides/billing-and-deposits/)). Unused free tokens do not carry over to the next month. The grant is sized as at least 1M tokens of the most expensive model; cheaper models stretch further (e.g. ~6M tokens for BGE-M3) ([free tier page](https://gonkabroker.com/free-llm-api/)). While running on free-tier funds only, requests are capped at a lower rate; the current cap is returned as `maxRpm` by `/test-auth` ([limits](https://docs.gonkabroker.com/reference/limits-and-quotas/)).
[^15]: NVIDIA does not publish a public RPM/RPD table for hosted NIM endpoints. The official FAQ says the rate of requests varies per model and may vary with the number of concurrent users, and that you should check your account at build.nvidia.com ([NIM FAQ](https://forums.developer.nvidia.com/t/nvidia-nim-faq/300317)). Hosted endpoints are for prototyping, research, development, and testing; production use requires an NVIDIA AI Enterprise license.
